//#pragma once
//#include"Players.h"
//#include <SFML/Graphics.hpp>
//class Leaderboard {
//  private:
//      static const int MAX_PLAYERS = 10;
//      Players players[MAX_PLAYERS];
//      static int numPlayers;
//public:
//     Leaderboard();
//     void addPlayer(const Players& player);
//     void sortPlayers();
//     void display() const;  
//     string* GetTopThree();
//
//  
//};  
//
//
