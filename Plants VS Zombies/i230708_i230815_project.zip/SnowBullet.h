#pragma once
#include "Bullet.h"
class SnowBullet : public Bullet
{
public:
	SnowBullet();
};

