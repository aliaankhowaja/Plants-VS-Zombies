#include "SnowBullet.h"

SnowBullet::SnowBullet()
{
	texture.loadFromFile("Resources/Images/ProjectileSnowPea.png");
}
