#include "Screen.h"

//void Screen::operator=(Screen& screen)
//{
//	//this->window = screen.window;
//}

//Screen::Screen()
//{
//
//}

//void Screen::Update()
//{
//
//}
//
//void Screen::Draw() const
//{
//	window->draw(background);
//}
//
//
//Screen::Screen(sf::RenderWindow* window, const sf::Sprite& background)
//	: window(window), background(background)
//{
//}
